﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PBL3.Migrations
{
    /// <inheritdoc />
    public partial class updatedb1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ListSkill_Roles_RoleId",
                table: "ListSkill");

            migrationBuilder.DropIndex(
                name: "IX_ListSkill_RoleId",
                table: "ListSkill");

            migrationBuilder.DropColumn(
                name: "RoleId",
                table: "ListSkill");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "RoleId",
                table: "ListSkill",
                type: "int",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_ListSkill_RoleId",
                table: "ListSkill",
                column: "RoleId");

            migrationBuilder.AddForeignKey(
                name: "FK_ListSkill_Roles_RoleId",
                table: "ListSkill",
                column: "RoleId",
                principalTable: "Roles",
                principalColumn: "Id");
        }
    }
}
