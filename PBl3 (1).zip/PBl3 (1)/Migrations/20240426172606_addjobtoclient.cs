﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PBL3.Migrations
{
    /// <inheritdoc />
    public partial class addjobtoclient : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FreelancerSkill_Skills_skillsSkillID",
                table: "FreelancerSkill");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Skills",
                table: "Skills");

            migrationBuilder.RenameTable(
                name: "Skills",
                newName: "ListSkill");

            migrationBuilder.RenameColumn(
                name: "skillsSkillID",
                table: "FreelancerSkill",
                newName: "hasskillsSkillID");

            migrationBuilder.RenameIndex(
                name: "IX_FreelancerSkill_skillsSkillID",
                table: "FreelancerSkill",
                newName: "IX_FreelancerSkill_hasskillsSkillID");

            migrationBuilder.AddColumn<int>(
                name: "RoleId",
                table: "ListSkill",
                type: "int",
                nullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_ListSkill",
                table: "ListSkill",
                column: "SkillID");

            migrationBuilder.CreateTable(
                name: "job",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ClientId = table.Column<int>(type: "int", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ExpectedDuration = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PaymentType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    PaymentAmount = table.Column<double>(type: "float", nullable: false),
                    CreateTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    JobStatus = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreateBy = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IsDelete = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_job", x => x.ID);
                    table.ForeignKey(
                        name: "FK_job_Clients_ClientId",
                        column: x => x.ClientId,
                        principalTable: "Clients",
                        principalColumn: "ClientID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_ListSkill_RoleId",
                table: "ListSkill",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "IX_job_ClientId",
                table: "job",
                column: "ClientId");

            migrationBuilder.AddForeignKey(
                name: "FK_FreelancerSkill_ListSkill_hasskillsSkillID",
                table: "FreelancerSkill",
                column: "hasskillsSkillID",
                principalTable: "ListSkill",
                principalColumn: "SkillID",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ListSkill_Roles_RoleId",
                table: "ListSkill",
                column: "RoleId",
                principalTable: "Roles",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FreelancerSkill_ListSkill_hasskillsSkillID",
                table: "FreelancerSkill");

            migrationBuilder.DropForeignKey(
                name: "FK_ListSkill_Roles_RoleId",
                table: "ListSkill");

            migrationBuilder.DropTable(
                name: "job");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ListSkill",
                table: "ListSkill");

            migrationBuilder.DropIndex(
                name: "IX_ListSkill_RoleId",
                table: "ListSkill");

            migrationBuilder.DropColumn(
                name: "RoleId",
                table: "ListSkill");

            migrationBuilder.RenameTable(
                name: "ListSkill",
                newName: "Skills");

            migrationBuilder.RenameColumn(
                name: "hasskillsSkillID",
                table: "FreelancerSkill",
                newName: "skillsSkillID");

            migrationBuilder.RenameIndex(
                name: "IX_FreelancerSkill_hasskillsSkillID",
                table: "FreelancerSkill",
                newName: "IX_FreelancerSkill_skillsSkillID");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Skills",
                table: "Skills",
                column: "SkillID");

            migrationBuilder.AddForeignKey(
                name: "FK_FreelancerSkill_Skills_skillsSkillID",
                table: "FreelancerSkill",
                column: "skillsSkillID",
                principalTable: "Skills",
                principalColumn: "SkillID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
