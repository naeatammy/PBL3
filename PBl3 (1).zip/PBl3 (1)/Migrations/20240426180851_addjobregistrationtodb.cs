﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PBL3.Migrations
{
    /// <inheritdoc />
    public partial class addjobregistrationtodb : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "jobRegistrations",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FreelancerID = table.Column<int>(type: "int", nullable: false),
                    JobID = table.Column<int>(type: "int", nullable: false),
                    start_time = table.Column<DateTime>(type: "datetime2", nullable: false),
                    end_time = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_jobRegistrations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_jobRegistrations_Freelancers_FreelancerID",
                        column: x => x.FreelancerID,
                        principalTable: "Freelancers",
                        principalColumn: "FreelancerID",
						onDelete: ReferentialAction.NoAction,
						onUpdate: ReferentialAction.NoAction);
					table.ForeignKey(
                        name: "FK_jobRegistrations_job_JobID",
                        column: x => x.JobID,
                        principalTable: "job",
                        principalColumn: "ID",
						onDelete: ReferentialAction.NoAction,
						onUpdate: ReferentialAction.NoAction);
				});

            migrationBuilder.CreateIndex(
                name: "IX_jobRegistrations_FreelancerID",
                table: "jobRegistrations",
                column: "FreelancerID");

            migrationBuilder.CreateIndex(
                name: "IX_jobRegistrations_JobID",
                table: "jobRegistrations",
                column: "JobID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "jobRegistrations");
        }
    }
}
