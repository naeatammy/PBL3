﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PBL3.Migrations
{
    /// <inheritdoc />
    public partial class addreviewtodb : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Review",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    JobID = table.Column<int>(type: "int", nullable: false),
                    FreelancerID = table.Column<int>(type: "int", nullable: false),
                    ClientID = table.Column<int>(type: "int", nullable: false),
                    ReviewTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Grade = table.Column<int>(type: "int", nullable: false),
                    Comment = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Review", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Review_Clients_ClientID",
                        column: x => x.ClientID,
                        principalTable: "Clients",
                        principalColumn: "ClientID",
						onDelete: ReferentialAction.NoAction,
						onUpdate: ReferentialAction.NoAction);
					table.ForeignKey(
                        name: "FK_Review_Freelancers_FreelancerID",
                        column: x => x.FreelancerID,
                        principalTable: "Freelancers",
                        principalColumn: "FreelancerID",
						onDelete: ReferentialAction.NoAction,
						onUpdate: ReferentialAction.NoAction);
					table.ForeignKey(
                        name: "FK_Review_job_JobID",
                        column: x => x.JobID,
                        principalTable: "job",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.NoAction,
                        onUpdate: ReferentialAction.NoAction);
                    
                });

            migrationBuilder.CreateIndex(
                name: "IX_Review_ClientID",
                table: "Review",
                column: "ClientID");

            migrationBuilder.CreateIndex(
                name: "IX_Review_FreelancerID",
                table: "Review",
                column: "FreelancerID");

            migrationBuilder.CreateIndex(
                name: "IX_Review_JobID",
                table: "Review",
                column: "JobID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Review");
        }
    }
}
