﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PBL3.Migrations
{
    /// <inheritdoc />
    public partial class tg3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "JobSkill");

            migrationBuilder.CreateTable(
                name: "RequiredSkill",
                columns: table => new
                {
                    JobId = table.Column<int>(type: "int", nullable: false),
                    RequireSkillId = table.Column<int>(type: "int", nullable: false),
                    SkillID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RequiredSkill", x => new { x.JobId, x.RequireSkillId });
                    table.ForeignKey(
                        name: "FK_RequiredSkill_ListSkill_SkillID",
                        column: x => x.SkillID,
                        principalTable: "ListSkill",
                        principalColumn: "SkillID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_RequiredSkill_job_JobId",
                        column: x => x.JobId,
                        principalTable: "job",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_RequiredSkill_SkillID",
                table: "RequiredSkill",
                column: "SkillID");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "RequiredSkill");

            migrationBuilder.CreateTable(
                name: "JobSkill",
                columns: table => new
                {
                    RequiredSkillsSkillID = table.Column<int>(type: "int", nullable: false),
                    jobID = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JobSkill", x => new { x.RequiredSkillsSkillID, x.jobID });
                    table.ForeignKey(
                        name: "FK_JobSkill_ListSkill_RequiredSkillsSkillID",
                        column: x => x.RequiredSkillsSkillID,
                        principalTable: "ListSkill",
                        principalColumn: "SkillID",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_JobSkill_job_jobID",
                        column: x => x.jobID,
                        principalTable: "job",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_JobSkill_jobID",
                table: "JobSkill",
                column: "jobID");
        }
    }
}
