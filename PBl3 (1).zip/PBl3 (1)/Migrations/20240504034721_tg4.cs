﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PBL3.Migrations
{
    /// <inheritdoc />
    public partial class tg4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_RequiredSkill_ListSkill_SkillID",
                table: "RequiredSkill");

            migrationBuilder.DropPrimaryKey(
                name: "PK_RequiredSkill",
                table: "RequiredSkill");

            migrationBuilder.DropColumn(
                name: "RequireSkillId",
                table: "RequiredSkill");

            migrationBuilder.RenameColumn(
                name: "SkillID",
                table: "RequiredSkill",
                newName: "SkillId");

            migrationBuilder.RenameIndex(
                name: "IX_RequiredSkill_SkillID",
                table: "RequiredSkill",
                newName: "IX_RequiredSkill_SkillId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_RequiredSkill",
                table: "RequiredSkill",
                columns: new[] { "JobId", "SkillId" });

            migrationBuilder.AddForeignKey(
                name: "FK_RequiredSkill_ListSkill_SkillId",
                table: "RequiredSkill",
                column: "SkillId",
                principalTable: "ListSkill",
                principalColumn: "SkillID",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_RequiredSkill_ListSkill_SkillId",
                table: "RequiredSkill");

            migrationBuilder.DropPrimaryKey(
                name: "PK_RequiredSkill",
                table: "RequiredSkill");

            migrationBuilder.RenameColumn(
                name: "SkillId",
                table: "RequiredSkill",
                newName: "SkillID");

            migrationBuilder.RenameIndex(
                name: "IX_RequiredSkill_SkillId",
                table: "RequiredSkill",
                newName: "IX_RequiredSkill_SkillID");

            migrationBuilder.AddColumn<int>(
                name: "RequireSkillId",
                table: "RequiredSkill",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_RequiredSkill",
                table: "RequiredSkill",
                columns: new[] { "JobId", "RequireSkillId" });

            migrationBuilder.AddForeignKey(
                name: "FK_RequiredSkill_ListSkill_SkillID",
                table: "RequiredSkill",
                column: "SkillID",
                principalTable: "ListSkill",
                principalColumn: "SkillID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
